export interface Category {
    id:string,
    createdAt: Date,
    updatedAt: Date,
    category: string
};

export interface CategoryId {
    id:string,
}
